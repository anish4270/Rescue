package com.example.rescue;

public class Contacts {
    int id;
    String name,number, relationship;

    public Contacts(){

    }
    public Contacts(int id, String name, String number, String relationship){

        this.id=id;
        this.name=name;
        this.number=number;
        this.relationship=relationship;
    }
    public Contacts(String name, String number, String relationship){
        this.name=name;
        this.number=number;
        this.relationship=relationship;
    }

    public int getId() {
        return id;

    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }
}
