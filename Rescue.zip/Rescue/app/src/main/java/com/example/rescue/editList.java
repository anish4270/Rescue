package com.example.rescue;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class editList extends AppCompatActivity {
    Context context;
    DBHandler dbHandler;
    private List<Contacts> contacts;
     ListView list;
     Button bn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_list);

        context = this;
        dbHandler = new DBHandler(context);

        Log.d("count_c", "onCreate: " + dbHandler.getContactCount());

        list = findViewById(R.id.list);
        bn = findViewById(R.id.bn);
        contacts = new ArrayList<>();
        contacts = dbHandler.getALLContacts();
       bn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), contactInfo.class));
                finish();
            }
        });

        final String[] namesArray = new String[contacts.size()];

        for (int x = 0; x < contacts.size(); x++) {
                 namesArray[x] = contacts.get(x).getName();
            Log.d("array_names", "onCreate:" + namesArray[x] + contacts.size());
        }

        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.row, namesArray);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, final long l) {
                final Contacts contact = contacts.get(i);
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle(contact.getName())
                        .setMessage(" Number: "+contact.getNumber() + " \n " +"Relation: " +contact.getRelationship())
                        .setNegativeButton("Cancel",null)
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                                builder.setMessage("Are you sure you want to delete?")
                                        .setNegativeButton("no",null)
                                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                int result = dbHandler.deleteContact(contact.getId());
                                                if(result>0){
                                                    startActivity(new Intent(getApplicationContext(), editList.class));
                                                    finish();
                                                    Toast.makeText(editList.this,"Contact Deleted Successfully ",Toast.LENGTH_LONG).show();
                                                }
                                                else {
                                                    Toast.makeText(editList.this, "something wrong", Toast.LENGTH_LONG).show();
                                                }
                                            }

                                        })
                                        .show();
                                 /* int result = dbHandler.deleteContact(contact.getId());
                                  if(result>0){
                                      Toast.makeText(editList.this,"Contact Deleted Successfully ",Toast.LENGTH_LONG).show();
                                  }
                                  else {
                                      Toast.makeText(editList.this, "something wrong", Toast.LENGTH_LONG).show();
                                  }*/

                            }
                        })
                        .show();

            }


        });

    }
}

