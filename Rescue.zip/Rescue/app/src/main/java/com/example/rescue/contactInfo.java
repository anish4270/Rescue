package com.example.rescue;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class contactInfo extends AppCompatActivity {
    Context context;
    DBHandler dbHandler;
    EditText et_name, et_number;
    Button add,relation;
    String relationshipString;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_info);

        context = this;
        dbHandler = new DBHandler(context);
        et_name = (EditText)findViewById(R.id.name);
        et_number=(EditText)findViewById(R.id.number);

        relation=(Button)findViewById(R.id.relation);
        add = (Button)findViewById(R.id.add);
        relationshipString = "Unspecified";
        relation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CharSequence options[]= {"PARENTS","FRIEND","RELATIVE","OTHERS"};
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Choose Relationship Type").setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if(i==0){
                            relationshipString = "PARENTS";
                        }
                        else if(i==1){
                            relationshipString = "FRIEND";
                        }
                        else if(i==2){
                            relationshipString = "RELATIVE";
                        }
                        else if(i==3){
                            relationshipString = "OTHERS";
                        }
                    }
                }) .show();
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = et_name.getText().toString();
                String number = et_number.getText().toString();


               /* if(name.trim().length() > 0 && number.trim().length() > 0 ){
                    Contacts contact = new Contacts(name,number,relationshipString);
                    dbHandler.addContact(contact);
                    Toast.makeText(contactInfo.this,"Successfully added!",Toast.LENGTH_LONG).show();
                }*/

                if(!TextUtils.isEmpty(name) && !TextUtils.isEmpty(number)){
                    Contacts contact = new Contacts(name,number,relationshipString);
                    dbHandler.addContact(contact);
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    finish();
                    Toast.makeText(contactInfo.this,"Contact Added Successfully!!",Toast.LENGTH_LONG).show();
                } else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setMessage("All field are required ")
                            .setNegativeButton("OK", null)
                            .show();
                }
            }
        });
    }

}
