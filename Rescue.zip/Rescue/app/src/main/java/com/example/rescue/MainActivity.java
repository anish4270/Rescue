package com.example.rescue;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    DBHandler dbHandler;
    private List<Contacts> contacts;
    Context context;
private static final int REQUEST_CALL = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.rescuelayout);
        context = this;
        dbHandler = new DBHandler(context);
        final ListView listView = new ListView(this);
        contacts = new ArrayList<>();
        contacts = dbHandler.getALLContacts();

        final TextView rescueScreen = findViewById(R.id.rescueScreen);
        final LinearLayout contact = findViewById(R.id.add_contact);
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), contactInfo.class));
            }

        });
        final LinearLayout dial = findViewById(R.id.dial);
        dial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dialIntent=new Intent(Intent.ACTION_CALL);
                dialIntent.setData(Uri.parse("tel: 123" ));
                //startActivity(dialIntent);
                if (ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
                } /*if(ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.CALL_PRIVILEGED) != PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
                }*/
                else {
                    //String dial = "tel: 3563037780";
                    //startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
                    startActivity(dialIntent);
                }
            }
        });
        final LinearLayout editContact = findViewById(R.id.editContact);
        editContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),editList.class));
            }
        });
        final String[] namesArray = new String[contacts.size()];
        for (int x = 0; x < contacts.size(); x++) {
            namesArray[x] = contacts.get(x).getName();
            Log.d("array_names", "onCreate:" + namesArray[x] + contacts.size());
        }
        final String[] numArray = new String[contacts.size()];
        for (int x = 0; x < contacts.size(); x++) {
            numArray[x] = contacts.get(x).getNumber();
            Log.d("array_names", "onCreate:" + numArray[x] + contacts.size());
        }
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Choose the contact to share location: ");
        final ArrayAdapter<String>adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,namesArray);
        listView.setAdapter(adapter);
        builder.setView(listView);
        builder.setNegativeButton("Cancel",null);
        final AlertDialog dialog = builder.create();

        final LinearLayout shareLocation = findViewById(R.id.shareLocation);
        shareLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               dialog.show();
            }
        });

        final LinearLayout notify = findViewById(R.id.notify);
        notify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = "RESCUE ALERT !!!!!";
                NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this)
                        .setSmallIcon(R.drawable.ic_verified)
                        .setContentTitle("Alert Notification")
                        .setContentText(message)
                        .setAutoCancel(true);
                Intent intent = new Intent();
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("message",message);
                PendingIntent pendingIntent = PendingIntent.getActivity(MainActivity.this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pendingIntent);

                NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.notify(0,builder.build());
            }
        });

        final LinearLayout voice = findViewById(R.id.voice);
        voice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        final Button logOut = findViewById(R.id.logOut);
        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Login_Form.class));
                finish();

            }
        });
    }
}