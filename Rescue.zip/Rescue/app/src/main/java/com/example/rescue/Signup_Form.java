package com.example.rescue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Signup_Form extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup__form);
        // getSupportActionBar().setTitle("Sign Up");

    }

    public void btn_registerForm(View view) {
        startActivity(new Intent(getApplicationContext(),Login_Form.class));
    }
}
